import printerPro from "../assets/images/printer_pro.png";
import catalogPro from "../assets/images/catalog_pro.png";
import devicesPro from "../assets/images/devices_pro.png";
import cloudPro from "../assets/images/cloud_pro.png";

const demonstrativeExamples = [9, 27, 35, 46, 52, 66, 83];

export function DemonstrativeSection() {
  return (
    <>
      <section id="secao-2" className="bg-[#E9F2F5] text-pv-text px-4 pt-10 pb-6 sm:pt-14 sm:pb-8">
        <div className="max-w-pv-container mx-auto">
          <div className="text-center max-w-4xl mx-auto mb-6">
            <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black font-heading tracking-tight leading-[1.1] mb-3 text-pv-primary">
              VEJA COMO É SIMPLES CONSULTAR UM DEFEITO
            </h2>
            <p className="text-lg sm:text-xl font-medium text-pv-text-muted">
              Você não precisa ler páginas e páginas para descobrir por onde começar.
            </p>
          </div>
          
          <div className="relative overflow-hidden w-screen max-w-full -mx-4 sm:-mx-0 mb-6">
            <div className="marquee-track space-x-6 py-4">
              {[0, 1].map((copy) => (
                <div key={copy} className="flex shrink-0 space-x-6">
                  {demonstrativeExamples.map((example) => (
                    <img
                      key={`${copy}-${example}`}
                      src={`/diagnosticos/${example}.png`}
                      alt="Exemplo de diagnóstico visual de impressora"
                      className="h-[400px] sm:h-[600px] md:h-[800px] w-auto object-contain rounded-lg shadow-md"
                      draggable={false}
                    />
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* SEÇÃO OS 150 DIAGNÓSTICOS POSSUEM COM OS ÍCONES ILUSTRADOS ORIGINAIS */}
      <section id="secao-3" className="bg-white border-t border-[#D8E5EF] px-4 pt-6 pb-12 sm:pt-8 sm:pb-16 text-pv-text">
        <div className="max-w-pv-container mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-10">
            <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black font-heading tracking-tight leading-[1.1] uppercase text-pv-primary">
              OS 150 DIAGNÓSTICOS POSSUEM:
            </h2>
          </div>

          <div className="grid md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            <div className="group bg-white rounded-2xl p-6 sm:p-7 flex items-center gap-5 sm:gap-6 border border-[#D8E5EF] shadow-xs transition-all duration-300 hover:shadow-md hover:-translate-y-0.5">
              <div className="w-18 h-18 sm:w-20 sm:h-20 shrink-0 flex items-center justify-center">
                <img 
                  src={printerPro} 
                  alt="Diagnóstico de impressora em 1 página" 
                  className="max-h-full max-w-full object-contain drop-shadow-sm transition-transform duration-300 group-hover:scale-105" 
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
              </div>
              <p className="text-base sm:text-lg text-pv-text leading-relaxed">
                <strong className="text-pv-primary">Um defeito inteiro em uma página só:</strong> sintoma observado, causas mais prováveis, verificações na ordem e próximo passo.
              </p>
            </div>

            <div className="group bg-white rounded-2xl p-6 sm:p-7 flex items-center gap-5 sm:gap-6 border border-[#D8E5EF] shadow-xs transition-all duration-300 hover:shadow-md hover:-translate-y-0.5">
              <div className="w-18 h-18 sm:w-20 sm:h-20 shrink-0 flex items-center justify-center">
                <img 
                  src={catalogPro} 
                  alt="Organização por sintoma e sistema" 
                  className="max-h-full max-w-full object-contain drop-shadow-sm transition-transform duration-300 group-hover:scale-105" 
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
              </div>
              <p className="text-base sm:text-lg text-pv-text leading-relaxed">
                <strong className="text-pv-primary">Organização por sintoma e por sistema:</strong> índice visual para achar o diagnóstico em poucos toques.
              </p>
            </div>

            <div className="group bg-white rounded-2xl p-6 sm:p-7 flex items-center gap-5 sm:gap-6 border border-[#D8E5EF] shadow-xs transition-all duration-300 hover:shadow-md hover:-translate-y-0.5">
              <div className="w-18 h-18 sm:w-20 sm:h-20 shrink-0 flex items-center justify-center">
                <img 
                  src={devicesPro} 
                  alt="Versão digital e impressa A4" 
                  className="max-h-full max-w-full object-contain drop-shadow-sm transition-transform duration-300 group-hover:scale-105" 
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
              </div>
              <p className="text-base sm:text-lg text-pv-text leading-relaxed">
                <strong className="text-pv-primary">Versão digital para o celular e versão A4:</strong> para imprimir e deixar em uma pasta na bancada.
              </p>
            </div>

            <div className="group bg-white rounded-2xl p-6 sm:p-7 flex items-center gap-5 sm:gap-6 border border-[#D8E5EF] shadow-xs transition-all duration-300 hover:shadow-md hover:-translate-y-0.5">
              <div className="w-18 h-18 sm:w-20 sm:h-20 shrink-0 flex items-center justify-center">
                <img 
                  src={cloudPro} 
                  alt="Download imediato com acesso vitalício" 
                  className="max-h-full max-w-full object-contain drop-shadow-sm transition-transform duration-300 group-hover:scale-105" 
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
              </div>
              <p className="text-base sm:text-lg text-pv-text leading-relaxed">
                <strong className="text-pv-primary">Download imediato:</strong> sem mensalidade e com acesso vitalício.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
