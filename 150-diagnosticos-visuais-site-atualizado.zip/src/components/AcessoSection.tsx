import cartPro from "../assets/images/cart_pro.png";
import memberPro from "../assets/images/member_pro.png";
import foldersPro from "../assets/images/folders_pro.png";
import benchPro from "../assets/images/bench_pro.png";

export function AcessoSection() {
  return (
    <section id="secao-11" className="bg-white text-pv-text px-4 pt-12 pb-14 sm:pt-16 sm:pb-20 border-t border-[#D8E5EF]">
      <div className="max-w-pv-container mx-auto text-center">
        <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black font-heading tracking-tight leading-[1.1] mb-2 text-pv-primary">
          COMO É O ACESSO
        </h2>
        <p className="text-sm sm:text-base font-bold uppercase tracking-wider text-[#3D6470] mb-10">
          (VEJA COMO É SIMPLES ACESSAR OS DIAGNÓSTICOS)
        </p>
        
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto mb-10 text-left">
          
          {/* Card 1 */}
          <div className="group p-6 sm:p-7 rounded-2xl bg-[#E9F2F5] border border-[#D8E5EF] flex flex-col shadow-xs transition-all duration-300 hover:shadow-md hover:-translate-y-1">
            <div className="h-28 flex items-center justify-center mb-4">
              <img 
                src={cartPro} 
                alt="Conclua sua compra com segurança" 
                className="max-h-24 sm:max-h-28 w-auto object-contain drop-shadow-md transition-transform duration-300 group-hover:scale-105"
                referrerPolicy="no-referrer"
                loading="lazy"
              />
            </div>
            <h3 className="font-black font-heading text-center text-lg sm:text-xl mb-2 text-pv-primary">
              Conclua sua compra
            </h3>
            <p className="text-xs sm:text-sm text-pv-text-muted text-center leading-relaxed mb-6">
              Após o pagamento, seu acesso é liberado automaticamente (Pagamento seguro, confirmação imediata).
            </p>
            <ul className="space-y-2.5 text-xs sm:text-sm text-pv-text mt-auto pt-4 border-t border-[#D8E5EF]">
              <li className="flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-emerald-100 text-pv-success flex items-center justify-center text-xs font-bold shrink-0">✓</span>
                <span>Pagamento 100% seguro</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-emerald-100 text-pv-success flex items-center justify-center text-xs font-bold shrink-0">✓</span>
                <span>Confirmação imediata</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-emerald-100 text-pv-success flex items-center justify-center text-xs font-bold shrink-0">✓</span>
                <span>Acesso direto ao material</span>
              </li>
            </ul>
          </div>

          {/* Card 2 */}
          <div className="group p-6 sm:p-7 rounded-2xl bg-[#E9F2F5] border border-[#D8E5EF] flex flex-col shadow-xs transition-all duration-300 hover:shadow-md hover:-translate-y-1">
            <div className="h-28 flex items-center justify-center mb-4">
              <img 
                src={memberPro} 
                alt="Entre na área de membros" 
                className="max-h-24 sm:max-h-28 w-auto object-contain drop-shadow-md transition-transform duration-300 group-hover:scale-105"
                referrerPolicy="no-referrer"
                loading="lazy"
              />
            </div>
            <h3 className="font-black font-heading text-center text-lg sm:text-xl mb-2 text-pv-primary">
              Entre na área de membros
            </h3>
            <p className="text-xs sm:text-sm text-pv-text-muted text-center leading-relaxed mb-6">
              Acesse seu painel com todos os diagnósticos e bônus (Visualização fácil e organização por sintoma).
            </p>
            <ul className="space-y-2.5 text-xs sm:text-sm text-pv-text mt-auto pt-4 border-t border-[#D8E5EF]">
              <li className="flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-emerald-100 text-pv-success flex items-center justify-center text-xs font-bold shrink-0">✓</span>
                <span>Visualização fácil</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-emerald-100 text-pv-success flex items-center justify-center text-xs font-bold shrink-0">✓</span>
                <span>Organização por sintoma</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-emerald-100 text-pv-success flex items-center justify-center text-xs font-bold shrink-0">✓</span>
                <span>Download rápido dos PDFs</span>
              </li>
            </ul>
          </div>

          {/* Card 3 */}
          <div className="group p-6 sm:p-7 rounded-2xl bg-[#E9F2F5] border border-[#D8E5EF] flex flex-col shadow-xs transition-all duration-300 hover:shadow-md hover:-translate-y-1">
            <div className="h-28 flex items-center justify-center mb-4">
              <img 
                src={foldersPro} 
                alt="Baixe os arquivos" 
                className="max-h-24 sm:max-h-28 w-auto object-contain drop-shadow-md transition-transform duration-300 group-hover:scale-105"
                referrerPolicy="no-referrer"
                loading="lazy"
              />
            </div>
            <h3 className="font-black font-heading text-center text-lg sm:text-xl mb-2 text-pv-primary">
              Baixe os arquivos
            </h3>
            <p className="text-xs sm:text-sm text-pv-text-muted text-center leading-relaxed mb-6">
              Salve tudo no celular, no tablet ou no computador (Arquivos em alta resolução, prontos para imprimir em A4).
            </p>
            <ul className="space-y-2.5 text-xs sm:text-sm text-pv-text mt-auto pt-4 border-t border-[#D8E5EF]">
              <li className="flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-emerald-100 text-pv-success flex items-center justify-center text-xs font-bold shrink-0">✓</span>
                <span>Alta resolução</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-emerald-100 text-pv-success flex items-center justify-center text-xs font-bold shrink-0">✓</span>
                <span>Prontos para imprimir em A4</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-emerald-100 text-pv-success flex items-center justify-center text-xs font-bold shrink-0">✓</span>
                <span>Ficam salvos com você</span>
              </li>
            </ul>
          </div>

          {/* Card 4 */}
          <div className="group p-6 sm:p-7 rounded-2xl bg-[#E9F2F5] border border-[#D8E5EF] flex flex-col shadow-xs transition-all duration-300 hover:shadow-md hover:-translate-y-1">
            <div className="h-28 flex items-center justify-center mb-4">
              <img 
                src={benchPro} 
                alt="Use na bancada" 
                className="max-h-24 sm:max-h-28 w-auto object-contain drop-shadow-md transition-transform duration-300 group-hover:scale-105"
                referrerPolicy="no-referrer"
                loading="lazy"
              />
            </div>
            <h3 className="font-black font-heading text-center text-lg sm:text-xl mb-2 text-pv-primary">
              Use na bancada
            </h3>
            <p className="text-xs sm:text-sm text-pv-text-muted text-center leading-relaxed mb-6">
              Abra o diagnóstico com a impressora na sua frente (Busca rápida pelo índice e acesso vitalício).
            </p>
            <ul className="space-y-2.5 text-xs sm:text-sm text-pv-text mt-auto pt-4 border-t border-[#D8E5EF]">
              <li className="flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-emerald-100 text-pv-success flex items-center justify-center text-xs font-bold shrink-0">✓</span>
                <span>Busca rápida pelo índice</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-emerald-100 text-pv-success flex items-center justify-center text-xs font-bold shrink-0">✓</span>
                <span>Consulta enquanto você trabalha</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-emerald-100 text-pv-success flex items-center justify-center text-xs font-bold shrink-0">✓</span>
                <span>Acesso vitalício</span>
              </li>
            </ul>
          </div>

        </div>

        <div>
          <a 
            href="#planos" 
            className="inline-block px-10 py-5 text-lg sm:text-xl font-bold rounded-full bg-pv-success hover:bg-[#126B33] transition-transform duration-300 hover:scale-[1.05] active:scale-[0.98] text-white shadow-[0_14px_30px_-10px_rgba(22,128,60,0.5)] uppercase tracking-wide"
          >
            QUERO ACESSAR AGORA
          </a>
        </div>
      </div>
    </section>
  );
}
