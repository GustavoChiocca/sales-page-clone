const bonuses = [
  {
    num: "1",
    title: "50 ERROS E CÓDIGOS DE IMPRESSORAS — O QUE PODEM INDICAR E O QUE VERIFICAR",
    desc: "Uma biblioteca adicional com 50 mensagens e códigos de erro recorrentes, mostrando o significado e o que eles podem indicar. Quando um código ou aviso aparecer no equipamento, você terá uma referência pronta para consultar em vez de começar procurando aquele erro do zero.",
    img: "/bonus/bonus-1.png",
  },
  {
    num: "2",
    title: "30 PROBLEMAS DE WI-FI E REDE — IMPRESSORA OFFLINE, SEM CONEXÃO E SEM COMUNICAÇÃO",
    desc: "Uma coleção específica para impressoras que ficam offline, somem da rede, perdem conexão ou simplesmente deixam de imprimir pelo computador ou celular. Cada problema apresenta possíveis causas e pontos de verificação para ajudar você a organizar a investigação.",
    img: "/bonus/bonus-2.png",
  },
  {
    num: "3",
    title: "30 PROBLEMAS DE PAPEL — ATOLAMENTOS, FOLHAS DUPLAS, PAPEL TORTO E FALHAS DE ALIMENTAÇÃO",
    desc: "Atolamento. Folhas puxadas juntas. Papel torto. Papel amassando. Impressora que tenta puxar e não consegue. Este material reúne 30 situações relacionadas ao transporte e à alimentação do papel para você consultar justamente quando esses sintomas aparecerem.",
    img: "/bonus/bonus-3.png",
  },
  {
    num: "4",
    title: "CHECKLIST DE DIAGNÓSTICO — O QUE VERIFICAR ANTES DE PARTIR PARA HIPÓTESES MAIS COMPLEXAS",
    desc: "Antes de partir para uma hipótese mais complexa, existem verificações básicas que não deveriam ser esquecidas. Por isso, você recebe um checklist pronto para usar como roteiro quando uma impressora chegar para análise. Uma maneira simples de evitar que um detalhe básico passe despercebido durante o diagnóstico.",
    img: "/bonus/bonus-4.png",
  },
  {
    num: "5",
    title: "30 CUIDADOS PARA PROLONGAR A VIDA ÚTIL DA IMPRESSORA",
    desc: "Uma lista prática com 30 cuidados relacionados a limpeza, papel, tinta, armazenamento, conservação e uso correto do equipamento. Cada item mostra o que fazer, o que evitar e quais problemas aquela prática ajuda a prevenir. Pode ser usado como referência durante orientações ao cliente e trabalhos preventivos.",
    img: "/bonus/bonus-5.png",
  },
  {
    num: "6",
    title: "25 ERROS DE USO QUE PODEM PROVOCAR FALHAS E DESGASTE",
    desc: "Nem todo problema nasce de uma peça defeituosa. Alguns começam em hábitos de uso que aumentam desgaste, provocam falhas ou reduzem a vida útil do equipamento. Neste guia você encontra 25 erros recorrentes, os riscos relacionados e a conduta preventiva correspondente.",
    img: "/bonus/bonus-6.png",
  },
  {
    num: "7",
    title: "CHECKLIST DE MANUTENÇÃO PREVENTIVA — PONTOS QUE NÃO DEVEM SER ESQUECIDOS",
    desc: "Um roteiro pronto para acompanhar pontos importantes como limpeza, alimentação de papel, sistema de impressão, roletes, conexões e outros componentes. Pode ser utilizado durante manutenções preventivas ou como rotina de acompanhamento para não esquecer itens importantes.",
    img: "/bonus/bonus-7.png",
  },
];

export function BonusSection() {
  return (
    <section id="secao-8" className="bg-[#E9F2F5] border-t border-[#D8E5EF] px-4 pt-10 pb-12 sm:pt-14 sm:pb-16 text-pv-text">
      <div className="max-w-pv-container mx-auto text-center">
        <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black font-heading tracking-tight leading-[1.1] mb-2 text-pv-primary">
          E PARA DEIXAR SUA BIBLIOTECA DE CONSULTA AINDA MAIS COMPLETA...
        </h2>
        <p className="text-xl sm:text-2xl italic font-bold mb-8 text-[#3D6470]">
          Você também recebe 7 materiais extras.
        </p>
        
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto text-left">
          {bonuses.map((bonus) => (
            <div 
              key={bonus.num} 
              className="rounded-pv overflow-hidden flex flex-col bg-white border border-[#D8E5EF] shadow-xs transition-transform duration-300 hover:scale-[1.03]"
            >
              <div className="relative bg-[#E9F2F5]/60 flex items-center justify-center p-4">
                <img 
                  src={bonus.img} 
                  alt={`Bônus #${bonus.num} Cover`} 
                  className="h-72 w-full object-contain"
                  loading="lazy"
                />
                <span className="absolute top-3 right-3 text-xs font-black px-3 py-1.5 rounded-full bg-[#123B4A] text-white shadow-xs">
                  BÔNUS #{bonus.num}
                </span>
              </div>
              <div className="p-6 flex-1 flex flex-col gap-4">
                <h3 className="font-black font-heading leading-tight text-xl text-pv-primary">
                  {bonus.title}
                </h3>
                <p className="text-sm sm:text-base text-pv-text-muted leading-relaxed">
                  {bonus.desc}
                </p>
                <div className="mt-auto pt-4 flex justify-center">
                  <div className="inline-flex items-center gap-2.5 text-sm sm:text-base font-bold px-5 py-2.5 rounded-full bg-[#123B4A] text-white shadow-xs">
                    <span className="text-[#F4B83F] font-black text-sm sm:text-base tracking-wide uppercase">
                      INCLUÍDO NO PLANO COMPLETO
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
