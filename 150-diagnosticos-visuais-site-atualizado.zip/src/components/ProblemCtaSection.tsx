const investigationExamples = [86, 94, 106, 130, 27, 46, 83];

export function ProblemCtaSection() {
  return (
    <section id="secao-4" className="bg-pv-primary text-white pt-10 pb-10 sm:pt-14 sm:pb-14 overflow-hidden">
      <div className="max-w-pv-container mx-auto">
        
        <div className="max-w-3xl mx-auto text-center px-4 mb-8">
          <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black font-heading tracking-tight leading-[1.1] text-white mb-6">
            QUEM TRABALHA COM IMPRESSORAS SABE COMO É...
          </h2>
          <div className="space-y-3 text-base sm:text-lg text-white/90 leading-relaxed max-w-2xl mx-auto">
            <p>
              Você recebe a impressora com um defeito, testa uma hipótese, não era aquilo, e logo se vê pesquisando em fóruns e vídeos para tentar descobrir por onde começar.
            </p>
            <p className="font-semibold text-white">
              Com os 150 Diagnósticos Visuais, você consulta o sintoma, confere as possíveis causas e segue uma linha lógica de verificação para conduzir o atendimento com mais direção.
            </p>
          </div>
          <div className="mt-6 inline-block py-2 px-6 rounded-full bg-[#3D6470] text-white font-black text-sm sm:text-base tracking-wider uppercase border border-white/20">
            PARE DE COMEÇAR CADA DEFEITO DO ZERO.
          </div>
        </div>

        <div className="relative overflow-hidden w-screen max-w-full -mx-4 sm:-mx-0 mb-10">
          <div className="marquee-track space-x-6 py-2">
            {[0, 1].map((copy) => (
              <div key={copy} className="flex shrink-0 space-x-6">
                {investigationExamples.map((example) => (
                  <img
                    key={`${copy}-${example}`}
                    src={`/diagnosticos/${example}.png`}
                    alt="Exemplo de diagnóstico visual de impressora"
                    className="h-[380px] sm:h-[550px] w-auto object-contain rounded-lg shadow-lg"
                    draggable={false}
                  />
                ))}
              </div>
            ))}
          </div>
        </div>

        <div className="max-w-3xl mx-auto text-center px-4">
          <h2 className="text-2xl sm:text-4xl lg:text-5xl font-black font-heading tracking-tight leading-[1.15] text-white mb-4">
            TENHA UMA REFERÊNCIA PRONTA PARA A PRÓXIMA IMPRESSORA QUE CHEGAR NA SUA BANCADA
          </h2>
          <p className="text-base sm:text-lg text-white/85 mb-8 font-medium">
            Em vez de depender apenas da memória ou começar uma nova pesquisa, consulte primeiro os diagnósticos.
          </p>
          
          <a 
            href="#planos" 
            className="inline-block px-10 py-5 text-lg sm:text-xl font-bold rounded-full bg-pv-success hover:bg-[#126B33] focus:outline-none focus:ring-2 focus:ring-pv-success focus:ring-offset-2 focus:ring-offset-pv-primary transition-transform duration-300 hover:scale-[1.05] active:scale-[0.98] text-white shadow-[0_14px_30px_-10px_rgba(22,128,60,0.5)] uppercase tracking-wide"
          >
            QUERO ACESSAR OS DIAGNÓSTICOS
          </a>
        </div>
      </div>
    </section>
  );
}
