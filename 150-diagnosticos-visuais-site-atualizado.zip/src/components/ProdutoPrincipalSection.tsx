export function ProdutoPrincipalSection() {
  return (
    <section id="secao-7" className="bg-white text-pv-text px-4 pt-10 pb-10 sm:pt-14 sm:pb-14 border-t border-[#D8E5EF]">
      <div className="max-w-pv-container mx-auto">
        <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black font-heading tracking-tight leading-[1.1] text-center mb-8 text-pv-primary">
          TUDO O QUE VOCÊ VAI RECEBER
        </h2>
        
        <div className="max-w-2xl mx-auto rounded-pv overflow-hidden p-6 sm:p-10 space-y-8 bg-pv-primary text-white border-2 border-[#3D6470] shadow-xl">
          <div className="text-center">
            <span className="inline-block text-sm sm:text-base font-extrabold px-6 py-2.5 rounded-full bg-white/15 text-white border border-white/20">
              ⚡ ACESSO DIGITAL
            </span>
          </div>
          <h3 className="text-2xl sm:text-3xl font-black font-heading text-center tracking-tight leading-snug text-white">
            150 DIAGNÓSTICOS VISUAIS DE IMPRESSORAS
          </h3>
          <p className="text-center text-sm sm:text-base text-white/80 leading-normal">
            Uma biblioteca para consultar sempre que um sintoma aparecer na sua bancada. Entre os exemplos do material estão falhas de inicialização, alimentação de papel, impressão clara ou manchada, vazamentos de tinta, estação de limpeza, carro de impressão, engrenagens e conexão de rede.
          </p>
          
          <div className="flex justify-center my-4">
            <img 
              src="/mockups/plano-completo.png" 
              alt="150 Diagnósticos Mockup" 
              className="max-h-[330px] sm:max-h-[420px] object-contain rounded-lg w-full"
              loading="lazy"
            />
          </div>

          <ul className="divide-y divide-white/10 text-sm sm:text-base pt-2">
            <li className="flex gap-3 items-start py-3">
              <svg className="h-5 w-5 text-[#E9F2F5] shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
              <span className="font-extrabold text-white">150 Diagnósticos Visuais de Impressoras</span>
            </li>
            <li className="flex gap-3 items-start py-3">
              <svg className="h-5 w-5 text-[#E9F2F5] shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
              <span className="font-bold text-white">Sintoma, possíveis causas e pontos de verificação organizados para consulta</span>
            </li>
            <li className="flex gap-3 items-start py-3">
              <svg className="h-5 w-5 text-[#E9F2F5] shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
              <span className="font-bold text-white">Sequência de investigação para eliminar possibilidades</span>
            </li>
            <li className="flex gap-3 items-start py-3">
              <svg className="h-5 w-5 text-[#E9F2F5] shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
              <span className="font-bold text-white">Possíveis soluções e orientação para o próximo passo</span>
            </li>
            <li className="flex gap-3 items-start py-3">
              <svg className="h-5 w-5 text-[#E9F2F5] shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
              <span className="font-bold text-white">Falhas de inicialização e equipamentos que não concluem o ciclo</span>
            </li>
            <li className="flex gap-3 items-start py-3">
              <svg className="h-5 w-5 text-[#E9F2F5] shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
              <span className="font-bold text-white">Problemas de alimentação, papel e avisos de “sem papel”</span>
            </li>
            <li className="flex gap-3 items-start py-3">
              <svg className="h-5 w-5 text-[#E9F2F5] shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
              <span className="font-bold text-white">Impressão clara, manchas e outras falhas de qualidade</span>
            </li>
            <li className="flex gap-3 items-start py-3">
              <svg className="h-5 w-5 text-[#E9F2F5] shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
              <span className="font-bold text-white">Vazamentos de tinta, cabeça e estação de limpeza</span>
            </li>
            <li className="flex gap-3 items-start py-3">
              <svg className="h-5 w-5 text-[#E9F2F5] shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
              <span className="font-bold text-white">Carro de impressão, movimento, engrenagens e falhas mecânicas</span>
            </li>
            <li className="flex gap-3 items-start py-3">
              <svg className="h-5 w-5 text-[#E9F2F5] shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
              <span className="font-bold text-white">Falhas de comunicação, Wi-Fi e rede</span>
            </li>
            <li className="flex gap-3 items-start py-3">
              <svg className="h-5 w-5 text-[#E9F2F5] shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
              <span className="font-bold text-white">Material visual e digital para consulta recorrente</span>
            </li>
          </ul>

          <div className="text-center pt-2">
            <p className="font-bold text-base sm:text-lg text-[#E9F2F5]">
              Você não precisa decorar 150 defeitos.
            </p>
            <p className="text-sm sm:text-base text-white/80">
              Precisa saber onde consultar quando um deles aparecer.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
