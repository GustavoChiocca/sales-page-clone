import garantiaPro from "../assets/images/garantia_pro.png";

export function GarantiaSection() {
  return (
    <section id="secao-10" className="bg-[#E9F2F5] text-pv-text px-4 pt-12 pb-14 sm:pt-16 sm:pb-20 border-t border-[#D8E5EF]">
      <div className="max-w-pv-container mx-auto">
        <div className="max-w-4xl mx-auto flex flex-col md:flex-row items-center md:items-start gap-8 sm:gap-12">
          
          {/* Selo 30 Dias */}
          <div className="shrink-0 flex justify-center">
            <img 
              src={garantiaPro} 
              alt="Garantia Incondicional de 30 Dias" 
              className="w-56 sm:w-64 md:w-72 h-auto object-contain drop-shadow-[0_15px_35px_rgba(20,40,70,0.22)] hover:scale-105 transition-transform duration-300 select-none"
              referrerPolicy="no-referrer"
              loading="lazy"
            />
          </div>

          {/* Conteúdo da Garantia */}
          <div className="text-left flex-1">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black font-heading tracking-tight leading-[1.15] text-pv-primary mb-4 uppercase">
              GARANTIA DE 30 DIAS — TESTE O MATERIAL SEM DECIDIR NO ESCURO
            </h2>

            <div className="space-y-4 text-base sm:text-lg text-pv-text mb-6 leading-relaxed">
              <p>Depois da compra, você poderá acessar os diagnósticos e conferir por conta própria como o material foi organizado.</p>
              <p>Se, dentro dos próximos 30 dias, você entender que o conteúdo não atende ao que esperava, poderá solicitar o reembolso conforme as condições da plataforma.</p>
            </div>

            <div className="border-t border-[#D8E5EF] pt-4">
              <p className="text-sm sm:text-base text-pv-text-muted font-normal leading-relaxed">
                Você entra, vê o material e decide com ele na sua frente.
              </p>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
