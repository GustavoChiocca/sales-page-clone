import { ModalProps } from "../types";

export function DiscountModal({ open, onClose }: ModalProps) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-fade-in">
      <div 
        className="relative w-full max-w-lg rounded-2xl bg-[#123B4A] text-white p-6 sm:p-8 border-2 border-[#3D6470] shadow-2xl overflow-hidden"
        role="dialog" 
        aria-modal="true"
      >
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-white/60 hover:text-white transition-colors text-2xl font-bold p-1 leading-none cursor-pointer"
          aria-label="Fechar"
        >
          ×
        </button>

        <div className="text-center space-y-4">
          <span className="inline-block text-xs font-black px-4 py-1.5 rounded-full bg-[#3D6470] text-white uppercase tracking-wider">
            ⭐ OPORTUNIDADE EXCLUSIVA
          </span>

          <h3 className="text-2xl sm:text-3xl font-black font-heading tracking-tight leading-tight text-white">
            ESCOLHA A BIBLIOTECA COMPLETA
          </h3>

          <p className="text-sm sm:text-base text-white/85 leading-relaxed">
            Em vez de levar apenas os diagnósticos básicos, garanta agora todos os <strong>7 materiais bônus</strong> inclusos:
          </p>

          <ul className="text-left text-xs sm:text-sm space-y-2 bg-white/5 p-4 rounded-xl border border-white/10 text-white/90">
            <li className="flex items-center gap-2">
              <svg className="h-4 w-4 text-[#E9F2F5] shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
              <span>150 Diagnósticos Visuais de Impressoras</span>
            </li>
            <li className="flex items-center gap-2">
              <svg className="h-4 w-4 text-[#E9F2F5] shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
              <span>50 Erros e Códigos de Impressoras Explicados</span>
            </li>
            <li className="flex items-center gap-2">
              <svg className="h-4 w-4 text-[#E9F2F5] shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
              <span>30 Problemas de Wi-Fi e Rede</span>
            </li>
            <li className="flex items-center gap-2">
              <svg className="h-4 w-4 text-[#E9F2F5] shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
              <span>30 Problemas de Papel + Soluções</span>
            </li>
            <li className="flex items-center gap-2">
              <svg className="h-4 w-4 text-[#E9F2F5] shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
              <span>Checklists de Diagnóstico e Manutenção</span>
            </li>
          </ul>

          <div className="pt-2">
            <a 
              href="https://pay.hotmart.com/R107304807U?off=y38dugls&checkoutMode=10"
              className="block w-full py-4 px-6 rounded-full font-bold bg-pv-success text-white hover:bg-[#126B33] transition-transform duration-300 hover:scale-[1.02] active:scale-[0.98] uppercase text-sm sm:text-base tracking-wide shadow-lg"
            >
              SIM! QUERO A BIBLIOTECA COMPLETA POR R$ 27,90
            </a>
          </div>

          <div>
            <a 
              href="https://pay.hotmart.com/R107304807U?off=0oheq5j6&checkoutMode=10"
              className="inline-block text-xs text-white/70 hover:text-white underline transition-colors pt-2"
            >
              Não, quero continuar apenas com o Plano Básico de R$ 19,90
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
