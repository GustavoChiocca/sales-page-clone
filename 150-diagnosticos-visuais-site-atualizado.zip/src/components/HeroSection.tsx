export function HeroSection() {
  return (
    <>
      <div id="secao-0" className="w-full text-center text-sm sm:text-base py-3 px-4 font-extrabold tracking-wide bg-[#F4B83F] text-[#102A43] shadow-sm flex items-center justify-center gap-1.5 flex-wrap">
        <span>🔒 ACESSO DIGITAL • COMPRA SEGURA</span>
      </div>

      <section id="secao-1" className="bg-pv-primary text-white px-4 py-8 sm:py-14">
        <div className="max-w-pv-container mx-auto text-center">
          
          <span className="inline-block text-xs sm:text-sm font-bold px-6 py-2 mb-6 text-white">
            REFERÊNCIA PRÁTICA PARA SUA BANCADA
          </span>
          
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black font-heading tracking-tight leading-[1.1] max-w-4xl mx-auto mb-6 text-white">
            150 DIAGNÓSTICOS VISUAIS PARA SABER O QUE VERIFICAR PRIMEIRO QUANDO UMA IMPRESSORA CHEGA COM DEFEITO
          </h1>
          
          <p className="text-lg sm:text-xl lg:text-2xl max-w-3xl mx-auto mb-8 text-white/90 font-medium leading-normal">
            Consulte o sintoma, veja as possíveis causas e siga uma sequência de verificação para encontrar o próximo passo — sem começar cada diagnóstico pesquisando tudo do zero.
          </p>
          
          <div className="mb-8 max-w-[800px] mx-auto">
            <img 
              src="/mockups/plano-completo.png" 
              alt="150 Diagnósticos Visuais de Impressoras Mockup" 
              className="w-full h-auto object-contain max-h-[380px] sm:max-h-[520px] rounded-pv mx-auto" 
              loading="eager"
            />
          </div>
          
          <div className="max-w-3xl mx-auto space-y-6 text-base sm:text-lg text-white/90 mb-6 text-left sm:text-center leading-relaxed">
            <p>
              A impressora não puxa papel. Imprime em branco. Mancha a folha. Não reconhece o cartucho. Apresenta erro. Perde a conexão com o Wi-Fi.
            </p>
            <p className="font-medium text-white/95">
              Você já sabe qual é o sintoma. A dúvida normalmente vem depois: <em className="text-[#E9F2F5] not-italic font-bold">“O que pode estar causando isso e o que eu verifico primeiro?”</em>
            </p>
            <div className="space-y-3">
              <p>Você já sabe mexer no equipamento. A dificuldade aparece quando o mesmo sintoma pode apontar para várias possibilidades.</p>
              <p>Você testa uma hipótese. Não era aquilo. Verifica outra. Abre o equipamento e começa a pensar em sensor, cabo, alimentação, cartucho, placa ou mecanismo.</p>
              <p>Quando percebe, já abriu vídeo, fórum, grupo ou pesquisa para tentar lembrar por onde começar — e o tempo de bancada vai embora antes mesmo de você conseguir organizar as hipóteses.</p>
            </div>
            <p className="border-t border-white/10 pt-6 font-semibold text-white">
              É justamente nesse momento que entram os 150 Diagnósticos Visuais. Você consulta o sintoma, vê as possíveis causas, segue os pontos de verificação e vai eliminando possibilidades com mais direção.
            </p>
          </div>
          
          <div className="max-w-2xl mx-auto text-left mb-8 bg-white/5 p-6 rounded-pv border border-white/10">
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <svg className="h-5 w-5 shrink-0 text-[#E9F2F5] mt-0.5" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
                <span className="text-sm sm:text-base font-semibold text-white">150 defeitos e sintomas recorrentes de impressoras</span>
              </li>
              <li className="flex items-start gap-3">
                <svg className="h-5 w-5 shrink-0 text-[#E9F2F5] mt-0.5" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
                <span className="text-sm sm:text-base font-semibold text-white">Possíveis causas organizadas por problema</span>
              </li>
              <li className="flex items-start gap-3">
                <svg className="h-5 w-5 shrink-0 text-[#E9F2F5] mt-0.5" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
                <span className="text-sm sm:text-base font-semibold text-white">Pontos que devem ser verificados em cada situação</span>
              </li>
              <li className="flex items-start gap-3">
                <svg className="h-5 w-5 shrink-0 text-[#E9F2F5] mt-0.5" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
                <span className="text-sm sm:text-base font-semibold text-white">Sequências visuais para orientar a investigação</span>
              </li>
              <li className="flex items-start gap-3">
                <svg className="h-5 w-5 shrink-0 text-[#E9F2F5] mt-0.5" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
                <span className="text-sm sm:text-base font-semibold text-white">Possíveis soluções e próximos passos</span>
              </li>
            </ul>
          </div>
          
          <div>
            <a 
              href="#planos" 
              className="inline-block px-10 py-5 text-lg sm:text-xl font-bold rounded-full bg-pv-success hover:bg-[#126B33] focus:outline-none focus:ring-2 focus:ring-pv-success focus:ring-offset-2 focus:ring-offset-pv-primary transition-transform duration-300 hover:scale-[1.05] active:scale-[0.98] text-white shadow-[0_14px_30px_-10px_rgba(22,128,60,0.5)] uppercase tracking-wide"
            >
              QUERO ACESSAR OS 150 DIAGNÓSTICOS
            </a>
            <p className="text-sm text-white/80 mt-4">
              📲 Acesso digital para consultar sempre que surgir um defeito na bancada
            </p>
          </div>
        </div>
      </section>
    </>
  );
}
