export function IdealParaVoceSection() {
  return (
    <section id="secao-5" className="bg-[#E9F2F5] text-pv-text px-4 pt-10 pb-10 sm:pt-14 sm:pb-14 border-t border-[#D8E5EF]">
      <div className="max-w-pv-container mx-auto">
        <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black font-heading tracking-tight leading-[1.1] text-center mb-8 text-pv-primary">
          ESSE MATERIAL É PARA VOCÊ QUE QUER...
        </h2>
        
        <div className="flex justify-center mb-8">
          <img 
            src="/images/tecnico-consulta.png" 
            alt="Técnico consultando um guia de diagnóstico na bancada" 
            className="max-h-[440px] sm:max-h-[700px] w-auto object-contain rounded-pv shadow-md"
            loading="lazy"
          />
        </div>
        
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
          
          <div className="p-6 rounded-[14px] flex gap-3 items-start transition-transform duration-300 hover:scale-[1.03] bg-white border border-[#D8E5EF] shadow-xs">
            <span className="shrink-0 mt-1">
              <svg className="h-4 w-4 text-[#3D6470]" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
            </span>
            <div>
              <h3 className="font-black font-heading uppercase text-lg mb-2 text-pv-primary tracking-tight">SABER POR ONDE COMEÇAR</h3>
              <p className="text-sm sm:text-base text-pv-text-muted leading-relaxed">Quando surgir um sintoma, tenha uma primeira linha de investigação em vez de testar possibilidades aleatórias.</p>
            </div>
          </div>
          
          <div className="p-6 rounded-[14px] flex gap-3 items-start transition-transform duration-300 hover:scale-[1.03] bg-white border border-[#D8E5EF] shadow-xs">
            <span className="shrink-0 mt-1">
              <svg className="h-4 w-4 text-[#3D6470]" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
            </span>
            <div>
              <h3 className="font-black font-heading uppercase text-lg mb-2 text-pv-primary tracking-tight">PARAR DE DIAGNOSTICAR NO CHUTE</h3>
              <p className="text-sm sm:text-base text-pv-text-muted leading-relaxed">Organize as hipóteses antes de sair desmontando ou testando componentes sem uma sequência clara.</p>
            </div>
          </div>
          
          <div className="p-6 rounded-[14px] flex gap-3 items-start transition-transform duration-300 hover:scale-[1.03] bg-white border border-[#D8E5EF] shadow-xs">
            <span className="shrink-0 mt-1">
              <svg className="h-4 w-4 text-[#3D6470]" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
            </span>
            <div>
              <h3 className="font-black font-heading uppercase text-lg mb-2 text-pv-primary tracking-tight">VERIFICAR ANTES DE AVANÇAR PARA A TROCA DE PEÇAS</h3>
              <p className="text-sm sm:text-base text-pv-text-muted leading-relaxed">Consulte outras possíveis causas e pontos de verificação antes de partir para uma hipótese mais cara ou complexa.</p>
            </div>
          </div>
          
          <div className="p-6 rounded-[14px] flex gap-3 items-start transition-transform duration-300 hover:scale-[1.03] bg-white border border-[#D8E5EF] shadow-xs">
            <span className="shrink-0 mt-1">
              <svg className="h-4 w-4 text-[#3D6470]" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
            </span>
            <div>
              <h3 className="font-black font-heading uppercase text-lg mb-2 text-pv-primary tracking-tight">NÃO PARAR O ATENDIMENTO PARA PESQUISAR TUDO DO ZERO</h3>
              <p className="text-sm sm:text-base text-pv-text-muted leading-relaxed">Use uma referência pronta antes de abrir vídeos, fóruns ou grupos atrás de uma resposta.</p>
            </div>
          </div>
          
          <div className="p-6 rounded-[14px] flex gap-3 items-start transition-transform duration-300 hover:scale-[1.03] bg-white border border-[#D8E5EF] shadow-xs">
            <span className="shrink-0 mt-1">
              <svg className="h-4 w-4 text-[#3D6470]" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
            </span>
            <div>
              <h3 className="font-black font-heading uppercase text-lg mb-2 text-pv-primary tracking-tight">CONSULTAR O QUE VOCÊ NÃO LEMBRA DE CABEÇA</h3>
              <p className="text-sm sm:text-base text-pv-text-muted leading-relaxed">Use a biblioteca como uma memória externa para sintomas que você já encontrou, mas não lembra todos os detalhes.</p>
            </div>
          </div>
          
          <div className="p-6 rounded-[14px] flex gap-3 items-start transition-transform duration-300 hover:scale-[1.03] bg-white border border-[#D8E5EF] shadow-xs">
            <span className="shrink-0 mt-1">
              <svg className="h-4 w-4 text-[#3D6470]" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
            </span>
            <div>
              <h3 className="font-black font-heading uppercase text-lg mb-2 text-pv-primary tracking-tight">GIRAR A BANCADA COM MAIS AGILIDADE</h3>
              <p className="text-sm sm:text-base text-pv-text-muted leading-relaxed">Quanto menos tempo você perde tentando decidir o primeiro passo, mais rápido consegue avançar na análise do equipamento.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
