interface PricingSectionProps {
  onOpenModal?: () => void;
}

export function PricingSection({ onOpenModal: _onOpenModal }: PricingSectionProps) {
  return (
    <section id="planos" className="bg-white text-pv-text px-4 pt-10 pb-10 sm:pt-14 sm:pb-14 border-t border-[#D8E5EF]">
      <div className="max-w-pv-container mx-auto">
        <div className="max-w-3xl mx-auto text-center mb-6 text-base sm:text-lg text-pv-text-muted leading-relaxed">
          <p>Toda vez que uma impressora entra na bancada, você pode depender só da memória e começar uma nova pesquisa…</p>
          <p className="font-bold text-pv-primary mt-2">ou abrir uma referência pronta e começar a investigação com uma linha de raciocínio organizada.</p>
        </div>
        <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black font-heading tracking-tight leading-[1.1] text-center mb-8 text-pv-primary">
          ESCOLHA COMO VOCÊ QUER ACESSAR
        </h2>
        
        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto items-stretch">
          
          {/* PLANO BÁSICO */}
          <div className="rounded-pv overflow-hidden p-6 sm:p-8 flex flex-col justify-between bg-[#E9F2F5] border border-[#D8E5EF] shadow-xs">
            <div>
              <span className="inline-block text-xs font-bold px-3 py-1 rounded-full bg-white text-[#3D6470] border border-[#D8E5EF] mb-4">
                ACESSO DIGITAL
              </span>
              <h3 className="font-black font-heading text-2xl mb-1 text-pv-primary">
                150 DIAGNÓSTICOS VISUAIS
              </h3>
              <p className="text-sm text-pv-text-muted mb-4">
                Acesso ao material principal para consulta em bancada.
              </p>

              {/* Mockup Plano Básico */}
              <div className="my-5 flex items-center justify-center">
                <img 
                  src="/mockups/plano-basico.png" 
                  alt="Mockup Plano Básico - 150 Diagnósticos Visuais" 
                  className="h-48 sm:h-56 w-auto max-w-full object-contain mx-auto drop-shadow-md"
                  loading="lazy"
                />
              </div>
              
              <ul className="space-y-3 text-sm sm:text-base border-t border-[#D8E5EF] pt-4">
                <li className="flex gap-2 items-center">
                  <svg className="h-5 w-5 text-[#3D6470] shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
                  <span className="font-bold text-pv-text">150 Diagnósticos Visuais de Impressoras</span>
                </li>
                <li className="flex gap-2 items-center">
                  <svg className="h-5 w-5 text-[#3D6470] shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
                  <span className="text-pv-text">Possíveis causas</span>
                </li>
                <li className="flex gap-2 items-center">
                  <svg className="h-5 w-5 text-[#3D6470] shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
                  <span className="text-pv-text">Pontos de verificação</span>
                </li>
                <li className="flex gap-2 items-center">
                  <svg className="h-5 w-5 text-[#3D6470] shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
                  <span className="text-pv-text">Sequência de investigação</span>
                </li>
                <li className="flex gap-2 items-center">
                  <svg className="h-5 w-5 text-[#3D6470] shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
                  <span className="text-pv-text">Possíveis soluções</span>
                </li>
                <li className="flex gap-2 items-center">
                  <svg className="h-5 w-5 text-[#3D6470] shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
                  <span className="text-pv-text">Acesso digital</span>
                </li>
              </ul>
            </div>
            
            <div className="mt-8">
              <div className="text-sm font-bold text-pv-text-muted">POR APENAS</div>
              <div className="text-3xl sm:text-4xl font-black font-heading text-[#16803C]">
                R$ 19,90
              </div>
              <div className="text-xs text-pv-text-muted mb-6">Valor à vista</div>
              
              <a 
                href="https://pay.hotmart.com/R107304807U?off=0oheq5j6&checkoutMode=10" 
                className="block text-center py-4 px-6 rounded-full font-bold bg-pv-success hover:bg-[#126B33] text-white transition-transform duration-300 hover:scale-[1.02] active:scale-[0.98] uppercase text-sm tracking-wide shadow-md"
              >
                QUERO O PLANO BÁSICO
              </a>
            </div>
          </div>
          
          {/* PLANO COMPLETO */}
          <div className="rounded-pv overflow-hidden p-6 sm:p-8 flex flex-col justify-between relative bg-[#123B4A] text-white border-2 border-[#3D6470] shadow-xl">
            <span className="absolute top-0 right-0 bg-[#3D6470] text-white font-black text-xs px-4 py-1.5 rounded-bl-lg uppercase tracking-wider">
              ⭐ MELHOR CUSTO-BENEFÍCIO
            </span>
            
            <div>
              <span className="inline-block text-xs font-bold px-3 py-1 rounded-full bg-white/15 text-white border border-white/20 mb-4">
                BIBLIOTECA COMPLETA
              </span>
              <h3 className="font-black font-heading text-2xl mb-1 text-white">
                BIBLIOTECA COMPLETA DE DIAGNÓSTICO
              </h3>
              <p className="text-sm text-white/80 mb-4">
                Por apenas R$ 8 a mais, você leva a Biblioteca Completa com os 150 diagnósticos + 7 materiais extras de consulta.
              </p>

              {/* Mockup Plano Completo */}
              <div className="my-5 flex items-center justify-center">
                <img 
                  src="/mockups/plano-completo.png" 
                  alt="Mockup Plano Completo - Biblioteca Completa de Diagnósticos" 
                  className="h-48 sm:h-56 w-auto max-w-full object-contain mx-auto drop-shadow-md"
                  loading="lazy"
                />
              </div>
              
              <ul className="space-y-3 text-sm sm:text-base border-t border-white/10 pt-4">
                <li className="flex gap-2 items-center">
                  <svg className="h-5 w-5 text-[#E9F2F5] shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
                  <span className="font-black text-white">150 Diagnósticos Visuais de Impressoras</span>
                </li>
                <li className="flex gap-2 items-center">
                  <svg className="h-5 w-5 text-[#E9F2F5] shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
                  <span>50 Erros e Códigos — o que podem indicar e o que verificar</span>
                </li>
                <li className="flex gap-2 items-center">
                  <svg className="h-5 w-5 text-[#E9F2F5] shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
                  <span>30 Problemas de Wi-Fi e Rede — offline, sem conexão e sem comunicação</span>
                </li>
                <li className="flex gap-2 items-center">
                  <svg className="h-5 w-5 text-[#E9F2F5] shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
                  <span>30 Problemas de Papel — atolamentos, folhas duplas e falhas de alimentação</span>
                </li>
                <li className="flex gap-2 items-center">
                  <svg className="h-5 w-5 text-[#E9F2F5] shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
                  <span>Checklist de Diagnóstico — antes de hipóteses mais complexas</span>
                </li>
                <li className="flex gap-2 items-center">
                  <svg className="h-5 w-5 text-[#E9F2F5] shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
                  <span>30 Cuidados para Prolongar a Vida Útil da Impressora</span>
                </li>
                <li className="flex gap-2 items-center">
                  <svg className="h-5 w-5 text-[#E9F2F5] shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
                  <span>25 Erros de Uso que Podem Provocar Falhas e Desgaste</span>
                </li>
                <li className="flex gap-2 items-center">
                  <svg className="h-5 w-5 text-[#E9F2F5] shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" /></svg>
                  <span>Checklist de Manutenção Preventiva — pontos que não devem ser esquecidos</span>
                </li>
              </ul>
            </div>
            
            <div className="mt-8">
              <div className="text-sm font-bold text-[#E9F2F5]">POR APENAS</div>
              <div className="text-3xl sm:text-4xl font-black font-heading text-[#F4B83F]">
                R$ 27,90
              </div>
              <div className="text-xs text-white/70 mb-6">Valor à vista</div>
              
              <a 
                href="https://pay.hotmart.com/R107304807U?off=y38dugls&checkoutMode=10" 
                className="block text-center py-4 px-6 rounded-full font-bold bg-pv-success text-white hover:bg-[#126B33] transition-transform duration-300 hover:scale-[1.03] active:scale-[0.98] uppercase text-sm tracking-wide shadow-lg"
              >
                QUERO A BIBLIOTECA COMPLETA
              </a>
            </div>
          </div>
        </div>

        {/* Bloco de Valor e Segurança pós-oferta */}
        <div className="mt-10 max-w-3xl mx-auto bg-[#E9F2F5] border border-[#D8E5EF] p-5 sm:p-6 rounded-2xl flex items-start gap-4 text-left shadow-xs">
          <div className="w-8 h-8 rounded-full bg-[#123B4A] text-white flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="3" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <div>
            <p className="font-extrabold text-sm sm:text-base text-pv-primary uppercase tracking-tight mb-1">
              UMA ÚNICA PEÇA TROCADA SEM NECESSIDADE PODE CUSTAR MAIS QUE O ACESSO À BIBLIOTECA COMPLETA.
            </p>
            <p className="text-xs sm:text-sm text-pv-text-muted font-normal leading-relaxed">
              Ter uma referência para consultar antes de avançar nas hipóteses custa apenas R$ 27,90.
            </p>
          </div>
        </div>

        <p className="text-center text-xs sm:text-sm font-semibold text-pv-text-muted mt-5 flex items-center justify-center gap-1.5">
          <span>🔒</span> Compra 100% segura e garantida.
        </p>
      </div>
    </section>
  );
}
