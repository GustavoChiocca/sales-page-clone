import { useState } from "react";
import { ChevronDown, HelpCircle } from "lucide-react";

interface FaqItem {
  q: string;
  a: string;
}

const faqs: FaqItem[] = [
  {
    q: "O QUE EXATAMENTE SÃO OS 150 DIAGNÓSTICOS VISUAIS?",
    a: "São materiais de consulta organizados por sintomas e defeitos recorrentes de impressoras, apresentando possíveis causas, pontos de verificação, sequência de investigação e possíveis soluções para ajudar você a conduzir o diagnóstico com mais direção.",
  },
  {
    q: "OS DIAGNÓSTICOS GARANTEM QUE EU VOU ENCONTRAR O DEFEITO EXATO?",
    a: "Não. Um mesmo sintoma pode ter diferentes causas. O material funciona como uma referência para ajudar você a organizar hipóteses, saber o que verificar e eliminar possibilidades durante a investigação.",
  },
  {
    q: "SERVE PARA QUAIS MARCAS DE IMPRESSORA?",
    a: "O material foi organizado com base em sintomas e problemas recorrentes de impressoras. Diferentes modelos podem apresentar variações de construção, por isso a proposta é ajudar na investigação do sintoma, e não substituir procedimentos específicos de cada fabricante.",
  },
  {
    q: "SOU INICIANTE. VOU CONSEGUIR USAR?",
    a: "Sim. O material foi estruturado visualmente para facilitar a consulta de quem está começando e precisa de uma referência para saber o que verificar primeiro. Ele não substitui formação técnica, mas ajuda a organizar o raciocínio durante o diagnóstico.",
  },
  {
    q: "JÁ TRABALHO COM IMPRESSORAS. ISSO AINDA SERVE PARA MIM?",
    a: "Sim. Para quem já trabalha na área, o principal benefício é usar os diagnósticos como uma referência de bancada para defeitos que você não lembra de cabeça ou situações que deseja revisar rapidamente.",
  },
  {
    q: "ISSO É UM CURSO DE MANUTENÇÃO DE IMPRESSORAS?",
    a: "Não. O produto é uma Biblioteca Visual de Diagnóstico. Ele foi criado para consulta durante a rotina de manutenção, e não para ensinar manutenção completa do zero.",
  },
  {
    q: "POR QUE COMPRAR SE POSSO PESQUISAR NO GOOGLE OU YOUTUBE?",
    a: "Porque a proposta é reunir informações em uma estrutura organizada para consulta rápida. Em vez de começar uma nova pesquisa em vídeos, fóruns e páginas toda vez que surgir um problema, você começa com uma referência pronta por sintoma.",
  },
  {
    q: "COMO RECEBO O MATERIAL?",
    a: "O acesso é digital. Após a confirmação do pagamento, você recebe as instruções para acessar os diagnósticos e, no Plano Completo, também os bônus.",
  },
  {
    q: "POSSO BAIXAR E IMPRIMIR?",
    a: "Sim. Os materiais podem ser acessados digitalmente e, quando disponibilizados em formato A4, também podem ser impressos para consulta física na bancada.",
  },
  {
    q: "COMO FUNCIONA A GARANTIA DE 30 DIAS?",
    a: "Depois da compra, você tem 30 dias para acessar o conteúdo e avaliar se o material atende ao que esperava. Se não atender, poderá solicitar o reembolso conforme as condições da plataforma de pagamento.",
  },
];

export function FaqSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleFaq = (idx: number) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };

  return (
    <section id="secao-12" className="bg-[#E9F2F5] text-pv-text px-4 pt-14 pb-16 sm:pt-20 sm:pb-24 border-t border-[#D8E5EF]">
      <div className="max-w-pv-container mx-auto">
        <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white text-pv-primary border border-[#D8E5EF] font-bold text-xs uppercase tracking-wider mb-3">
            <HelpCircle className="w-4 h-4 text-[#3D6470]" />
            Dúvidas frequentes
          </div>
          <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black font-heading tracking-tight leading-[1.1] text-pv-primary uppercase">
            PERGUNTAS FREQUENTES
          </h2>
          <p className="text-sm sm:text-base font-bold uppercase tracking-wider text-[#3D6470] mt-2">
            (TIRE SUAS PRINCIPAIS DÚVIDAS SOBRE O MATERIAL)
          </p>
        </div>

        <div className="max-w-3xl mx-auto space-y-3.5">
          {faqs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div 
                key={idx} 
                className={`bg-white rounded-2xl border transition-all duration-200 overflow-hidden ${
                  isOpen 
                    ? "border-[#3D6470]/40 shadow-xs ring-1 ring-[#3D6470]/20" 
                    : "border-[#D8E5EF] shadow-xs hover:border-[#3D6470]/40"
                }`}
              >
                <button
                  type="button"
                  onClick={() => toggleFaq(idx)}
                  className="w-full text-left px-5 sm:px-7 py-4 sm:py-5 flex items-center justify-between gap-4 select-none focus:outline-hidden"
                  aria-expanded={isOpen}
                >
                  <span className="font-black font-heading text-base sm:text-lg tracking-tight text-pv-primary">
                    {faq.q}
                  </span>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-transform duration-300 ${
                    isOpen 
                      ? "bg-pv-primary text-white rotate-180" 
                      : "bg-[#E9F2F5] text-[#3D6470] hover:bg-[#D8E5EF]"
                  }`}>
                    <ChevronDown className="w-5 h-5" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 sm:px-7 pb-5 sm:pb-6 pt-1 text-sm sm:text-base text-pv-text-muted leading-relaxed border-t border-[#D8E5EF]">
                    <p className="pt-2">{faq.a}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Chamada Final no FAQ */}
        <div className="text-center mt-12">
          <a
            href="#planos"
            className="inline-block px-10 py-4 text-base sm:text-lg font-black rounded-full bg-pv-success hover:bg-[#126B33] transition-transform duration-300 hover:scale-[1.04] active:scale-[0.98] text-white shadow-[0_14px_30px_-10px_rgba(22,128,60,0.5)] uppercase tracking-wide"
          >
            ESCOLHER MEU PLANO AGORA
          </a>
        </div>
      </div>
    </section>
  );
}
