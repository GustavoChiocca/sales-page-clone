export function FooterSection() {
  return (
    <footer className="bg-pv-primary text-white py-10 px-4 border-t border-white/10">
      <div className="max-w-3xl mx-auto text-center space-y-3">
        <p className="font-semibold text-white/95 text-xs sm:text-sm tracking-wide">
          © {new Date().getFullYear()} 150 Diagnósticos Visuais de Impressoras · Todos os direitos reservados.
        </p>

        <p className="text-xs text-white/65 leading-relaxed">
          Todos os direitos sobre a obra “150 Diagnósticos Visuais de Impressoras” são protegidos pela Lei nº 9.610/98 e Art. 184 do Código Penal. A reprodução ou distribuição não autorizada desta publicação, no todo ou em parte, constitui violação de direitos autorais sujeita às sanções civis e criminais cabíveis.
        </p>

        <p className="text-[11px] text-white/50 leading-relaxed pt-1">
          Este site não é afiliado ao Facebook ou a qualquer entidade da Meta/Facebook. Após sair da plataforma, a responsabilidade é exclusiva do nosso site. Não vendemos suas informações para terceiros nem praticamos spam. Em caso de dúvidas, nosso atendimento funciona em dias úteis, das 09h00 às 18h00, com respostas por ordem de chegada.
        </p>
      </div>
    </footer>
  );
}
