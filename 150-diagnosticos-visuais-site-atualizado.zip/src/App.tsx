import { useState } from "react";
import { HeroSection } from "./components/HeroSection";
import { DemonstrativeSection } from "./components/DemonstrativeSection";
import { ProblemCtaSection } from "./components/ProblemCtaSection";
import { IdealParaVoceSection } from "./components/IdealParaVoceSection";
import { ProdutoPrincipalSection } from "./components/ProdutoPrincipalSection";
import { BonusSection } from "./components/BonusSection";
import { PricingSection } from "./components/PricingSection";
import { GarantiaSection } from "./components/GarantiaSection";
import { AcessoSection } from "./components/AcessoSection";
import { FaqSection } from "./components/FaqSection";
import { FooterSection } from "./components/FooterSection";
import { DiscountModal } from "./components/DiscountModal";

export default function App() {
  const [modalOpen, setModalOpen] = useState(false);

  return (
    <div className="font-sans antialiased bg-pv-bg text-pv-text selection:bg-pv-accent selection:text-white">
      {/* 1. Barra de Aviso & Hero */}
      <HeroSection />

      {/* 2. Demonstrativo & Características do Material */}
      <DemonstrativeSection />

      {/* 3. Identificação do Problema & CTA Intermediário */}
      <ProblemCtaSection />

      {/* 4. Ideal Para Você */}
      <IdealParaVoceSection />

      {/* 5. Produto Principal */}
      <ProdutoPrincipalSection />

      {/* 6. Os 7 Bônus Exclusivos */}
      <BonusSection />

      {/* 7. Oferta e Planos (Básico R$ 19,90 / Completo R$ 27,90) */}
      <PricingSection onOpenModal={() => setModalOpen(true)} />

      {/* 8. Garantia Incondicional */}
      <GarantiaSection />

      {/* 9. Como Funciona o Acesso */}
      <AcessoSection />

      {/* 10. Perguntas Frequentes (FAQ) */}
      <FaqSection />

      {/* 11. Rodapé e Direitos Autorais */}
      <FooterSection />

      {/* Modal de Upgrade ao Clicar no Plano Básico */}
      <DiscountModal open={modalOpen} onClose={() => setModalOpen(false)} />
    </div>
  );
}
